from . import b

def foo():
    b.bar()
