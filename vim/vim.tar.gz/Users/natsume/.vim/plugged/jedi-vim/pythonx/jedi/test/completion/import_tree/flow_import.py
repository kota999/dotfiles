if name:
    env = 1
else:
    env = 2
